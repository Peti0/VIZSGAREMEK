<div id="szurtautokkartya">
    <?php
    foreach ($db->szures() as $row) {
        $image = null;
        if (file_exists("./autokepek/" . $row['modell'] . "/kep1.jpg")) {
            $image = "./autokepek/" . $row['modell'] . "/kep1.jpg";
        } else {
            $image = "./images/noimage.jpg";
        }
        ?>
        <a href="index.php?menu=kivalasztottauto&id=<?php echo $row["id"]; ?>" >
            <div class="szurt-container">
                <img src="<?= $image ?>" id="szurtautok-kep" alt="...">
                <div id="container-felirat">
                    <h2  class="card-title"><?= $row['marka']?> <?= $row['modell']  ?></h2>
                <p class="card-text">Bérletidíj: <?= $row['berletidij'] ?> Ft</p>
            </div></div>
        </a>
        <?php
    }
    ?>
</div> 

